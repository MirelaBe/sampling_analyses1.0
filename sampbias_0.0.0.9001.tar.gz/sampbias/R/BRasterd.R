BRasterd <- function(x, sim.outp.path = NULL, verb = T, cellsize = 1, dat.thresh = 3, 
                     outp = c("stack", "sp.bias.eval.list"), ...){
  
  if (min(x[, 1]) * max(x[, 1]) < 0) {
    lonspan <- abs(min(x[, 1])) + abs(max(x[, 1]))
  } else {
    lonspan <- abs(abs(max(x[, 1])) - abs(min(x[, 1])))
  }
  if (min(x[, 2]) * max(x[, 2]) < 0) {
    latspan <- abs(min(x[, 2])) + abs(max(x[, 2]))
  } else {
    latspan <- abs(abs(max(x[, 2])) - abs(min(x[, 2])))
  }

  print("defining raster")
  ras <- raster(nrows = ceiling(lonspan/(cellsize)), 
                ncols = ceiling(latspan/(cellsize)), 
                xmn = min(x[, 1]), xmx = max(x[, 1]),
                ymn = min(x[, 2]), ymx = max(x[, 2]))
  ras <- setValues(ras, seq(1,ncell(ras)))
  df <- extract(ras, as.matrix(x))
  
  print("rasterize occurrence data")
  dat <- split(x, f = df)
  dat <- dat[unlist(lapply(dat, nrow)) > dat.thresh]
  print(sprintf("Found %s cells, %s with suficient data", ncell(ras),length(dat)))
  
  if(length(dat) == 0){
    stop("no cells matched the minimum number of records set in dat.thresh")
  }
  
#   
#   ras <- coordinates(raster(nrows = ceiling(lonspan/(cellsize)), 
#                             ncols = ceiling(latspan/(cellsize)), 
#                             xmn = min(x[, 1]), xmx = max(x[, 1]),
#                             ymn = min(x[, 2]), ymx = max(x[, 2])))
#   ras <- GridTopology(cellcentre.offset = c(min(x[, 1]), min(x[, 2])), 
#                              cellsize = c((cellsize), (cellsize)), 
#                              cells.dim = c(ceiling(lonspan/(cellsize)),
#                                            ceiling(latspan/(cellsize))))
#   ras <- coordinates(ras)
#   
#   cr <- list()
#   for (i in 1:dim(ras)[1]) {
#     cr[[i]] <- extent(c(ras[i, 1] - (cellsize - 1e-08), ras[i, 1] + 
#                           cellsize, ras[i, 2] - (cellsize - 1e-08), ras[i, 2] + cellsize))
#   }
#   names(cr) <- 1:length(cr)
#   print("rasterize occurrence data")
#   dat2 <- SpatialPoints(x)
#   rownames(dat2@coords) <- rownames(x)
#   dat <- lapply(cr, function(x) crop(dat2, x))
#   dat <- dat[!unlist(lapply(dat, is.null))]
#   dat <- lapply(dat, coordinates)
#   mis <- as.numeric(unlist(lapply(dat, rownames)))
#   mis <- x[which(!rownames(x) %in% mis), ]  # add entries missed by geographic splitting
#   dat[[length(dat) + 1]] <- mis
#   dat <- dat[[unlist(lapply(dat, length)) > dat.thresh]]
#   
#   print(sprintf("Found %s cells, %s with suficient data", length(dat)))
#   

  print("calculating sampling bias")
  samps <- lapply(dat, function(x) SamplingBiasLarge(x, tsocioeconomic = F, ...)) # check out why this gives a warning
  
  print("simulating random data")
  cell.coords <- data.frame(rasterToPoints(ras), row.names = NULL)
  sim.in <- data.frame(cell.coords [cell.coords $layer %in% names(dat),], row.names = NULL)
  sim.num <- unlist(lapply(dat, nrow), use.names = F)
  sims <- list()
  for(i in 1:nrow(sim.in)){
    sims[[i]] <- data.frame(x = runif(n = sim.num[i],
                                  min = (sim.in[i, 1] - cellsize / 2),
                                  max = (sim.in[i, 1] + cellsize / 2)),
                            y = runif(n = sim.num[i], 
                                  min = (sim.in[i, 2] - cellsize / 2), 
                                  max = (sim.in[i, 2] + cellsize / 2)))
  }
  print("calculating sampling for random data")
  sims <- lapply(sims, function(x) SamplingBiasLarge(x, tsocioeconomic = F, ...))
 
  lis <- c(1:length(samps))
  eva <- lapply(lis, function(x) BiasEval(samps[[x]], sims[[x]]))
  names(eva) <- names(samps)

  #output list
  if(outp[1] == "sp.bias.eval.list"){ 
    out <- as.list(rep(NA, ncell(ras)))
    for(i in 1:length(names(eva))){ out[[as.numeric(names(eva)[i])]] <- eva[i]}
    class(out) <- c("sp.bias.eval.list", class(out))
    }

  #output rasters
  if(outp[1] == "stack"){
    glob <- rep(NA, ncell(ras))
    vals <- unlist(lapply(eva, "[[", 1))
    glob[as.numeric(names(vals))] <- vals
    glob <- setValues(ras, glob)
    
    detai <- list()
    for(i in 1:nrow(data.frame(eva[[1]]["details"]))){
      vals <- do.call("rbind.data.frame", lapply(eva, function(x) data.frame(x["details"])[i,"details.partial.B"]))
      comb <- rep(NA, ncell(ras))
      comb[as.numeric(rownames(vals))] <- vals[,1]
      comb <- setValues(ras, comb)
      detai[i] <- comb
    }
    out <- stack(c(glob, detai))
    names(out) <- c("global B", paste("partial B - ", rownames(data.frame(eva[[1]]["details"])), sep = ""))
  }
  
  return(out)
}